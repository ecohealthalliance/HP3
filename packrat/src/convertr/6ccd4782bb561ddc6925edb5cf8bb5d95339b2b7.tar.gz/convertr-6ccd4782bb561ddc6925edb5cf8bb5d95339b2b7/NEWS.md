Version 0.11
--------------------------------------------------------------------------------
Added explore_units function to provide a shiny interface to the conversion table
Updated Documentation

Version 0.1
--------------------------------------------------------------------------------
New Features
* Added RStudio Add-in to build convertr expressions.
 
