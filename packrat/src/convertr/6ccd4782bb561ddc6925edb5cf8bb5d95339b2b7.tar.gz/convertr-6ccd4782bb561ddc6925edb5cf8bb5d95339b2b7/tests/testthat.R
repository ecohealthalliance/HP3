library(testthat)
library(convertr)

test_check("convertr")
