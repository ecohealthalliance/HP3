# forcats 0.1.1

* Minor fixes for R CMD check

* Add package docs
