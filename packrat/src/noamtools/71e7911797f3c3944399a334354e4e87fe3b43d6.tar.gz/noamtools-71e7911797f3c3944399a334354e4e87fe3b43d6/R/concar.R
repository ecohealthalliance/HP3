# #' @method + character
# #' @export
# "+.character" <- function(c1, c2) {
#   paste0(c1, c2)
# }
# 
# #' @export
# "%+%" <- `+.character`