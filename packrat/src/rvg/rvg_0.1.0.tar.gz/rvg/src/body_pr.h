class body_pr
{
public:
  static std::string a_tag();
  static std::string wps_tag();
};
