# selectr

[![Build Status](https://travis-ci.org/sjp/selectr.svg)](https://travis-ci.org/sjp/selectr)

Translate CSS Selectors to XPath Expressions
