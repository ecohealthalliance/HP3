## Test environments
* local OS X install, R 3.3.1
* ubuntu 12.04 (on travis-ci), R 3.3.1
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 1 note.

Lionel Henry is taking over as maintainer

## Downstream dependencies

* I ran R CMD check on all 5 downstream dependencies
  (https://github.com/hadley/svglite/blob/master/revdep/readme.md).
  No problems were found.
